package com.contact;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public class ContactDao {
	
	private static final Map<String, Contact> contMap = new HashMap<String, Contact>();
	static {
        initContact();
    }
 
  

	private static void initContact() {
		// TODO Auto-generated method stub
		Contact ct1 = new Contact("Parth", "9904836267");
		Contact ct2 = new Contact("Ruchit","9048383399");
		Contact ct3 = new Contact("Smit", "993838383");
		Contact ct4 = new Contact("Bhavesh", "949484848");
		Contact ct5 = new Contact("Omik", "939393939399");
		
		contMap.put(ct1.getContactName(),ct1);
		contMap.put(ct2.getContactName(),ct2);
		contMap.put(ct3.getContactName(),ct3);
		contMap.put(ct4.getContactName(),ct4);
		contMap.put(ct5.getContactName(),ct5);
		
		
	}
	//getContact
	public static Contact getContact(String contactName) {
		return contMap.get(contactName);
	}
	
	public static Contact addContact(Contact cont) {
		contMap.put(cont.getContactName(), cont);
		return cont;
	}
	public static Contact updateEmployee(Contact cont) {
		contMap.put(cont.getContactName(), cont);
        return cont;
    }
	public static void deleteContact(String contactName) {
		contMap.remove(contactName);
    }
	public static List<Contact> getAllContacts() {
        Collection<Contact> c = contMap.values();
        List<Contact> list = new ArrayList<Contact>();
        list.addAll(c);
        return list;
    }
     
    List<Contact> list;
	
	
}
