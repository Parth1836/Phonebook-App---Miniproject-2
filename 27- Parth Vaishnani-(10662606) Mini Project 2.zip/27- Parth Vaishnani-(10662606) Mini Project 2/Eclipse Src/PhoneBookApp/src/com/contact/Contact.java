package com.contact;

import javax.xml.bind.annotation.XmlRootElement;


//@XmlRootElement(name="contact")
public class Contact {
	
	String contactName;
	String contactNumber;
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Contact(String contactName, String contactNumber) {
		super();
		this.contactName = contactName;
		this.contactNumber = contactNumber;
	}
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
