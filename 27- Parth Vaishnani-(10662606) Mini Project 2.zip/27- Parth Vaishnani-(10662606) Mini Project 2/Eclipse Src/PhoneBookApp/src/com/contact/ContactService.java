package com.contact;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/contacts")
public class ContactService {
	
	// /http://localhost:8080/PhoneBookApp/rest/contacts
	@GET
	@Produces({ MediaType.APPLICATION_JSON})
	public List<Contact> getContacts_JSON() {
        List<Contact> listOfContacts = ContactDao.getAllContacts();
        return listOfContacts;
    }
	
	// /http://localhost:8080/PhoneBookApp/rest/contacts/Parth
	 @GET
	    @Path("/get/{contactName}")
	    @Produces({ MediaType.APPLICATION_JSON})
	    public Contact getContact(@PathParam("contactName") String contactName) {
	        return ContactDao.getContact(contactName);
	    }
	 
	// /http://localhost:8080/PhoneBookApp/rest/contacts/add
	 @POST
	 @Path("/add")
	    @Produces({ MediaType.APPLICATION_JSON})
	    public Contact addContact(Contact cont) {
	        return ContactDao.addContact(cont);
	    }
	 
	// /http://localhost:8080/PhoneBookApp/rest/contacts/update
	 @PUT
	 @Path("/update")
	    @Produces({ MediaType.APPLICATION_JSON})
	    public Contact updateContact(Contact cont) {
	        return ContactDao.updateEmployee(cont);
	    }
	 //http://localhost:8080/PhoneBookApp/rest/contacts/Parth
	 @DELETE
	    @Path("/delete/{contactName}")
	    @Produces({ MediaType.APPLICATION_JSON})
	    public void deleteContact(@PathParam("contactName") String contactName) {
		 ContactDao.deleteContact(contactName);
	    }
	
}
