import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Contact } from './Contacts';
@Injectable({
  providedIn: 'root'
})
export class ContactsService {
  url: string  = 'http://localhost:8080/PhoneBookApp/rest/contacts/';
  
  constructor(private http: HttpClient ) { }
   getAllContact() :Observable<Contact[]>
  {
    return this.http.get<Contact[]>(this.url);
  }
  getContact(contactName: String): Observable<Contact> 
  {
    return this.http.get<Contact>(this.url + "get/" + contactName);
  }
  
  deleteContact(contactName: String) : Observable<Contact>
  {
    return this.http.delete<Contact>(this.url + "delete/" + contactName);
                    
  }
 addContact(cont: Contact){
    let url = 'http://localhost:8080/PhoneBookApp/rest/contacts/add';
    return this.http.post(url,cont);
  }
  updateContact(cont: Contact){
    let url = 'http://localhost:8080/PhoneBookApp/rest/contacts/update';
    return this.http.put(url,cont);
  
  }
  modifyContact(cont: Contact): Observable<Contact>
  {
    return this.http.put<Contact>(this.url + "update/", cont);
  }
}



  /*addContact(cont: Contact): Observable<Contact>
  {
    return this.http.post<Contact>(this.url+"add/",cont);
  }

  modifyContact(existingcont: Contact): Observable<Contact>
  {
    return this.http.put<Contact>(this.url + "update/", existingcont);
  }*/