import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/internal/Subscription';
import { Contact } from '../Contacts';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-view-all-contacts',
  templateUrl: './view-all-contacts.component.html',
  styleUrls: ['./view-all-contacts.component.css']
})
export class ViewAllContactsComponent implements OnInit {

  contactName: string;
  contacts: Contact[];
  tempContacts: Contact[]; 

  private subscription: Subscription;
  constructor(private service: ContactsService) { }

  ngOnInit(): void {
    this.subscription = this.service.getAllContact().subscribe((data: Contact[])=>{
      this.contacts=data;
      this.tempContacts=data;
    },(err)=>{console.log(err);
    })
  }

  searchContact(){
    if(this.contactName == null)  {
      console.log('its empty : '+this.contactName);
      this.tempContacts = this.contacts;
  }
  else {
    console.log('its not zero : '+this.contactName);
    this.tempContacts = this.contacts.filter(data1 => (data1.contactName == this.contactName) );
    console.log('tempContacts length : '+this.contactName.length);
    console.log('contacts length : '+this.contacts.length);
      } //else ends

}
modifyContact(c: Contact){
  this.service.modifyContact(c).subscribe((data: Contact)=>{
    alert(JSON.stringify(data));
  })
}
deleteContact(x: string)
    {
      console.log('contact searched '+x);
      this.service.deleteContact(x)
      .subscribe((data: Contact) => { //data var should be same as getAll var
        alert(JSON.stringify('Deleting '+x));
        if(data == null)  {
          this.contacts = this.contacts.filter(d => (d.contactName != x) );
          this.contacts = this.tempContacts;
          console.log('Record deleted '+x);
          
        }
    }, (err) => {
        console.log(err);
    });
  
  }

}
