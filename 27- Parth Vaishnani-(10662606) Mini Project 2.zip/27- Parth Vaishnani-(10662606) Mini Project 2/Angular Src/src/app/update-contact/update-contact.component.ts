import { Component, OnInit } from '@angular/core';
import { Contact } from '../Contacts';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-update-contact',
  templateUrl: './update-contact.component.html',
  styleUrls: ['./update-contact.component.css']
})
export class UpdateContactComponent implements OnInit {
  cont: Contact = new Contact();
  constructor(private service: ContactsService) { 
    this.cont.contactName;
    this.cont.contactNumber;
  }
  modifyContact(){
    this.service.updateContact(this.cont).subscribe(data => {
      alert(JSON.stringify(data));
    })
    

  }
  ngOnInit(): void {
  }

}
