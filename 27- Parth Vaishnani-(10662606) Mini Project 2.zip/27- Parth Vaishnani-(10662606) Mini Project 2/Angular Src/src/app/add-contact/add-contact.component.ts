import { Component, OnInit } from '@angular/core';
import { Contact } from '../Contacts';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {
  cont: Contact = new Contact();
  constructor(private service: ContactsService) {
    this.cont.contactName;
    this.cont.contactNumber;
   }
   addContact(){
    this.service.addContact(this.cont).subscribe(data => {
      alert(JSON.stringify(data));
    })
  }
  ngOnInit(): void {
  }

}
