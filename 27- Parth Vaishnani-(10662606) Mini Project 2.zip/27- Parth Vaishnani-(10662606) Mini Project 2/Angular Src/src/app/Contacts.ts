export class Contact {
    contactName: String;
    contactNumber: String;
}